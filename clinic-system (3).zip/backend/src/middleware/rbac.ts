import { Request, Response, NextFunction } from 'express';
import { Role } from '@prisma/client';

/**
 * Restricts a route to the given roles. Must run after `authenticate`.
 * Usage: router.delete('/:id', authenticate, requireRole('ADMIN'), handler)
 */
export function requireRole(...allowedRoles: Role[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions for this action' });
    }
    return next();
  };
}
