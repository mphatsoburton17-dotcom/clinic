import { prisma } from '../../config/prisma';
import { AppError } from '../../middleware/errorHandler';

async function generateInvoiceNumber() {
  const count = await prisma.invoice.count();
  const year = new Date().getFullYear();
  return `INV-${year}-${String(count + 1).padStart(5, '0')}`;
}

export async function createInvoice(input: {
  patientId: string;
  dueDate?: Date;
  taxRate: number;
  lineItems: { description: string; quantity: number; unitPrice: number }[];
}) {
  const subtotal = input.lineItems.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
  const tax = subtotal * input.taxRate;
  const total = subtotal + tax;
  const invoiceNumber = await generateInvoiceNumber();

  return prisma.invoice.create({
    data: {
      patientId: input.patientId,
      invoiceNumber,
      dueDate: input.dueDate,
      subtotal,
      tax,
      total,
      status: 'ISSUED',
      lineItems: {
        create: input.lineItems.map((item) => ({
          description: item.description,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          amount: item.quantity * item.unitPrice,
        })),
      },
    },
    include: { lineItems: true },
  });
}

export async function getInvoiceById(id: string) {
  const invoice = await prisma.invoice.findUnique({
    where: { id },
    include: { lineItems: true, payments: true, patient: true },
  });
  if (!invoice) throw new AppError('Invoice not found', 404);
  return invoice;
}

export async function listInvoicesForPatient(patientId: string) {
  return prisma.invoice.findMany({
    where: { patientId },
    include: { lineItems: true, payments: true },
    orderBy: { issueDate: 'desc' },
  });
}

export async function recordPayment(
  invoiceId: string,
  input: { amount: number; method: string; transactionRef?: string }
) {
  const invoice = await getInvoiceById(invoiceId);

  const payment = await prisma.payment.create({
    data: { invoiceId, ...input },
  });

  const paidSoFar =
    invoice.payments.reduce((sum: number, p: { amount: unknown }) => sum + Number(p.amount), 0) + input.amount;
  const total = Number(invoice.total);

  let status: 'PARTIALLY_PAID' | 'PAID' = 'PARTIALLY_PAID';
  if (paidSoFar >= total) status = 'PAID';

  await prisma.invoice.update({ where: { id: invoiceId }, data: { status } });

  return payment;
}
