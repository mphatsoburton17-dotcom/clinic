import { Router } from 'express';
import * as billingService from './billing.service';
import { createInvoiceSchema, recordPaymentSchema } from './billing.validators';
import { authenticate } from '../../middleware/auth';
import { requireRole } from '../../middleware/rbac';

const router = Router();

router.use(authenticate);

router.post('/invoices', requireRole('ADMIN', 'RECEPTIONIST'), async (req, res, next) => {
  try {
    const data = createInvoiceSchema.parse(req.body);
    const invoice = await billingService.createInvoice(data);
    res.status(201).json(invoice);
  } catch (err) {
    next(err);
  }
});

router.get('/invoices/:id', async (req, res, next) => {
  try {
    const invoice = await billingService.getInvoiceById(req.params.id);
    res.json(invoice);
  } catch (err) {
    next(err);
  }
});

router.get('/patients/:patientId/invoices', async (req, res, next) => {
  try {
    const invoices = await billingService.listInvoicesForPatient(req.params.patientId);
    res.json(invoices);
  } catch (err) {
    next(err);
  }
});

router.post('/invoices/:id/payments', requireRole('ADMIN', 'RECEPTIONIST'), async (req, res, next) => {
  try {
    const data = recordPaymentSchema.parse(req.body);
    const payment = await billingService.recordPayment(req.params.id, data);
    res.status(201).json(payment);
  } catch (err) {
    next(err);
  }
});

export default router;
