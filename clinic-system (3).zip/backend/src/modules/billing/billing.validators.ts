import { z } from 'zod';

export const lineItemSchema = z.object({
  description: z.string().min(1),
  quantity: z.number().int().min(1).default(1),
  unitPrice: z.number().nonnegative(),
});

export const createInvoiceSchema = z.object({
  patientId: z.string().uuid(),
  dueDate: z.coerce.date().optional(),
  taxRate: z.number().min(0).max(1).default(0), // e.g. 0.08 for 8%
  lineItems: z.array(lineItemSchema).min(1),
});

export const recordPaymentSchema = z.object({
  amount: z.number().positive(),
  method: z.string().min(1),
  transactionRef: z.string().optional(),
});
