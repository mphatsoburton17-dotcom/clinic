import { Router } from 'express';
import * as appointmentsService from './appointments.service';
import {
  createAppointmentSchema,
  updateAppointmentSchema,
  listAppointmentsQuerySchema,
} from './appointments.validators';
import { authenticate } from '../../middleware/auth';
import { requireRole } from '../../middleware/rbac';

const router = Router();

router.use(authenticate);

router.get('/', async (req, res, next) => {
  try {
    const filters = listAppointmentsQuerySchema.parse(req.query);
    const appointments = await appointmentsService.listAppointments(filters);
    res.json(appointments);
  } catch (err) {
    next(err);
  }
});

router.post('/', requireRole('ADMIN', 'RECEPTIONIST'), async (req, res, next) => {
  try {
    const data = createAppointmentSchema.parse(req.body);
    const appointment = await appointmentsService.createAppointment(data);
    res.status(201).json(appointment);
  } catch (err) {
    next(err);
  }
});

router.patch('/:id', requireRole('ADMIN', 'RECEPTIONIST', 'DOCTOR', 'NURSE'), async (req, res, next) => {
  try {
    const data = updateAppointmentSchema.parse(req.body);
    const appointment = await appointmentsService.updateAppointment(req.params.id, data);
    res.json(appointment);
  } catch (err) {
    next(err);
  }
});

router.post('/:id/cancel', requireRole('ADMIN', 'RECEPTIONIST'), async (req, res, next) => {
  try {
    const appointment = await appointmentsService.cancelAppointment(req.params.id);
    res.json(appointment);
  } catch (err) {
    next(err);
  }
});

export default router;
