import { z } from 'zod';

export const createAppointmentSchema = z
  .object({
    patientId: z.string().uuid(),
    providerId: z.string().uuid(),
    startTime: z.coerce.date(),
    endTime: z.coerce.date(),
    reason: z.string().optional(),
    notes: z.string().optional(),
  })
  .refine((data) => data.endTime > data.startTime, {
    message: 'endTime must be after startTime',
    path: ['endTime'],
  });

export const updateAppointmentSchema = z.object({
  startTime: z.coerce.date().optional(),
  endTime: z.coerce.date().optional(),
  status: z.enum(['SCHEDULED', 'CONFIRMED', 'CHECKED_IN', 'COMPLETED', 'CANCELLED', 'NO_SHOW']).optional(),
  reason: z.string().optional(),
  notes: z.string().optional(),
});

export const listAppointmentsQuerySchema = z.object({
  providerId: z.string().uuid().optional(),
  patientId: z.string().uuid().optional(),
  from: z.coerce.date().optional(),
  to: z.coerce.date().optional(),
});
