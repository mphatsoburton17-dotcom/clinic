import { prisma } from '../../config/prisma';
import { AppError } from '../../middleware/errorHandler';
import { AppointmentStatus } from '@prisma/client';

async function assertNoOverlap(
  providerId: string,
  startTime: Date,
  endTime: Date,
  excludeAppointmentId?: string
) {
  const overlapping = await prisma.appointment.findFirst({
    where: {
      providerId,
      id: excludeAppointmentId ? { not: excludeAppointmentId } : undefined,
      status: { notIn: ['CANCELLED', 'NO_SHOW'] },
      AND: [{ startTime: { lt: endTime } }, { endTime: { gt: startTime } }],
    },
  });

  if (overlapping) {
    throw new AppError('This provider already has an appointment in that time slot', 409);
  }
}

export async function listAppointments(filters: {
  providerId?: string;
  patientId?: string;
  from?: Date;
  to?: Date;
}) {
  return prisma.appointment.findMany({
    where: {
      providerId: filters.providerId,
      patientId: filters.patientId,
      startTime: filters.from ? { gte: filters.from } : undefined,
      endTime: filters.to ? { lte: filters.to } : undefined,
    },
    include: {
      patient: { select: { id: true, firstName: true, lastName: true } },
      provider: { select: { id: true, firstName: true, lastName: true } },
    },
    orderBy: { startTime: 'asc' },
  });
}

export async function createAppointment(data: {
  patientId: string;
  providerId: string;
  startTime: Date;
  endTime: Date;
  reason?: string;
  notes?: string;
}) {
  await assertNoOverlap(data.providerId, data.startTime, data.endTime);
  return prisma.appointment.create({ data });
}

export async function updateAppointment(
  id: string,
  data: {
    startTime?: Date;
    endTime?: Date;
    status?: AppointmentStatus;
    reason?: string;
    notes?: string;
  }
) {
  const existing = await prisma.appointment.findUnique({ where: { id } });
  if (!existing) throw new AppError('Appointment not found', 404);

  if (data.startTime || data.endTime) {
    await assertNoOverlap(
      existing.providerId,
      data.startTime ?? existing.startTime,
      data.endTime ?? existing.endTime,
      id
    );
  }

  return prisma.appointment.update({ where: { id }, data });
}

export async function cancelAppointment(id: string) {
  const existing = await prisma.appointment.findUnique({ where: { id } });
  if (!existing) throw new AppError('Appointment not found', 404);
  return prisma.appointment.update({ where: { id }, data: { status: 'CANCELLED' } });
}
