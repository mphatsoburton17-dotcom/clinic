import { Router } from 'express';
import * as authService from './auth.service';
import { registerSchema, loginSchema, changePasswordSchema } from './auth.validators';
import { authenticate } from '../../middleware/auth';
import { requireRole } from '../../middleware/rbac';

const router = Router();

// Only admins can create new staff accounts (self-service signup is not appropriate for a clinic system)
router.post('/register', authenticate, requireRole('ADMIN'), async (req, res, next) => {
  try {
    const input = registerSchema.parse(req.body);
    const user = await authService.registerUser(input);
    res.status(201).json(user);
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = loginSchema.parse(req.body);
    const result = await authService.loginUser(email, password);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.post('/change-password', authenticate, async (req, res, next) => {
  try {
    const { oldPassword, newPassword } = changePasswordSchema.parse(req.body);
    await authService.changePassword(req.user!.id, oldPassword, newPassword);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

router.get('/me', authenticate, async (req, res) => {
  res.json({ user: req.user });
});

export default router;
