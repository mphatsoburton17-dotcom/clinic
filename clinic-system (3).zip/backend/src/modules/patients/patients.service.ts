import { prisma } from '../../config/prisma';
import { AppError } from '../../middleware/errorHandler';

export async function listPatients(search: string | undefined, page: number, pageSize: number) {
  const where = search
    ? {
        OR: [
          { firstName: { contains: search, mode: 'insensitive' as const } },
          { lastName: { contains: search, mode: 'insensitive' as const } },
          { email: { contains: search, mode: 'insensitive' as const } },
          { phone: { contains: search } },
        ],
      }
    : {};

  const [items, total] = await Promise.all([
    prisma.patient.findMany({
      where,
      skip: (page - 1) * pageSize,
      take: pageSize,
      orderBy: { lastName: 'asc' },
    }),
    prisma.patient.count({ where }),
  ]);

  return { items, total, page, pageSize };
}

export async function getPatientById(id: string) {
  const patient = await prisma.patient.findUnique({
    where: { id },
    include: { medicalRecords: { orderBy: { recordDate: 'desc' } } },
  });
  if (!patient) throw new AppError('Patient not found', 404);
  return patient;
}

export async function createPatient(data: Parameters<typeof prisma.patient.create>[0]['data']) {
  return prisma.patient.create({ data });
}

export async function updatePatient(id: string, data: Parameters<typeof prisma.patient.update>[0]['data']) {
  await getPatientById(id); // throws 404 if missing
  return prisma.patient.update({ where: { id }, data });
}

export async function deactivatePatient(id: string) {
  await getPatientById(id);
  return prisma.patient.update({ where: { id }, data: { isActive: false } });
}

export async function addMedicalRecord(
  patientId: string,
  recordedBy: string,
  data: { diagnosis?: string; notes?: string; attachments?: string[] }
) {
  await getPatientById(patientId);
  return prisma.medicalRecord.create({
    data: { patientId, recordedBy, ...data },
  });
}
