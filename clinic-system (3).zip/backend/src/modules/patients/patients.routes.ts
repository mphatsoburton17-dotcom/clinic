import { Router } from 'express';
import * as patientsService from './patients.service';
import {
  createPatientSchema,
  updatePatientSchema,
  createMedicalRecordSchema,
  listPatientsQuerySchema,
} from './patients.validators';
import { authenticate } from '../../middleware/auth';
import { requireRole } from '../../middleware/rbac';

const router = Router();

// All patient routes require authentication
router.use(authenticate);

// Admin, doctor, nurse, receptionist can all view patients
router.get('/', async (req, res, next) => {
  try {
    const { search, page, pageSize } = listPatientsQuerySchema.parse(req.query);
    const result = await patientsService.listPatients(search, page, pageSize);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get('/:id', async (req, res, next) => {
  try {
    const patient = await patientsService.getPatientById(req.params.id);
    res.json(patient);
  } catch (err) {
    next(err);
  }
});

// Receptionists and admins register new patients
router.post('/', requireRole('ADMIN', 'RECEPTIONIST'), async (req, res, next) => {
  try {
    const data = createPatientSchema.parse(req.body);
    const patient = await patientsService.createPatient(data);
    res.status(201).json(patient);
  } catch (err) {
    next(err);
  }
});

router.patch('/:id', requireRole('ADMIN', 'RECEPTIONIST', 'DOCTOR', 'NURSE'), async (req, res, next) => {
  try {
    const data = updatePatientSchema.parse(req.body);
    const patient = await patientsService.updatePatient(req.params.id, data);
    res.json(patient);
  } catch (err) {
    next(err);
  }
});

// Only admins can deactivate (soft delete) a patient record
router.delete('/:id', requireRole('ADMIN'), async (req, res, next) => {
  try {
    await patientsService.deactivatePatient(req.params.id);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// Doctors and nurses add clinical notes
router.post('/:id/medical-records', requireRole('ADMIN', 'DOCTOR', 'NURSE'), async (req, res, next) => {
  try {
    const data = createMedicalRecordSchema.parse(req.body);
    const record = await patientsService.addMedicalRecord(req.params.id, req.user!.id, data);
    res.status(201).json(record);
  } catch (err) {
    next(err);
  }
});

export default router;
