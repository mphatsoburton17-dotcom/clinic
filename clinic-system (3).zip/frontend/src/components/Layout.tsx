import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export function Layout() {
  const { user, logout } = useAuth();

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    `block px-4 py-2 rounded-md text-sm font-medium ${
      isActive ? 'bg-teal-600 text-white' : 'text-slate-600 hover:bg-slate-100'
    }`;

  return (
    <div className="flex min-h-screen">
      <aside className="w-56 border-r border-slate-200 bg-white p-4 flex flex-col">
        <h1 className="text-lg font-bold text-slate-800 mb-6">Clinic MS</h1>
        <nav className="space-y-1 flex-1">
          <NavLink to="/patients" className={linkClass}>Patients</NavLink>
          <NavLink to="/appointments" className={linkClass}>Appointments</NavLink>
        </nav>
        <div className="border-t border-slate-200 pt-4 text-sm">
          <p className="text-slate-500">{user?.email}</p>
          <p className="text-slate-400 text-xs mb-2">{user?.role}</p>
          <button onClick={logout} className="text-red-600 hover:underline text-sm">
            Sign out
          </button>
        </div>
      </aside>
      <main className="flex-1 p-8">
        <Outlet />
      </main>
    </div>
  );
}
