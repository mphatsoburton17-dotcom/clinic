import { useEffect, useState, FormEvent } from 'react';
import { api } from '../api/client';

interface Patient {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  phone?: string;
  email?: string;
}

export function Patients() {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const res = await api.get('/patients', { params: { search: search || undefined } });
    setPatients(res.data.items);
    setLoading(false);
  }

  useEffect(() => {
    const t = setTimeout(load, 300); // debounce search
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [search]);

  async function handleCreate(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    await api.post('/patients', {
      firstName: form.get('firstName'),
      lastName: form.get('lastName'),
      dateOfBirth: form.get('dateOfBirth'),
      phone: form.get('phone'),
      email: form.get('email'),
    });
    setShowForm(false);
    load();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-bold text-slate-800">Patients</h2>
        <button
          onClick={() => setShowForm((v) => !v)}
          className="bg-teal-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-teal-700"
        >
          {showForm ? 'Cancel' : '+ New Patient'}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="bg-white border border-slate-200 rounded-lg p-4 mb-6 grid grid-cols-2 gap-3">
          <input name="firstName" placeholder="First name" required className="border rounded-md px-3 py-2 text-sm" />
          <input name="lastName" placeholder="Last name" required className="border rounded-md px-3 py-2 text-sm" />
          <input name="dateOfBirth" type="date" required className="border rounded-md px-3 py-2 text-sm" />
          <input name="phone" placeholder="Phone" className="border rounded-md px-3 py-2 text-sm" />
          <input name="email" type="email" placeholder="Email" className="border rounded-md px-3 py-2 text-sm col-span-2" />
          <button type="submit" className="col-span-2 bg-teal-600 text-white rounded-md py-2 text-sm font-medium">
            Register Patient
          </button>
        </form>
      )}

      <input
        placeholder="Search patients..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full border border-slate-300 rounded-md px-3 py-2 mb-4 text-sm"
      />

      {loading ? (
        <p className="text-slate-500 text-sm">Loading...</p>
      ) : (
        <table className="w-full bg-white border border-slate-200 rounded-lg overflow-hidden text-sm">
          <thead className="bg-slate-100 text-left text-slate-600">
            <tr>
              <th className="px-4 py-2">Name</th>
              <th className="px-4 py-2">DOB</th>
              <th className="px-4 py-2">Phone</th>
              <th className="px-4 py-2">Email</th>
            </tr>
          </thead>
          <tbody>
            {patients.map((p) => (
              <tr key={p.id} className="border-t border-slate-100">
                <td className="px-4 py-2">{p.lastName}, {p.firstName}</td>
                <td className="px-4 py-2">{new Date(p.dateOfBirth).toLocaleDateString()}</td>
                <td className="px-4 py-2">{p.phone ?? '—'}</td>
                <td className="px-4 py-2">{p.email ?? '—'}</td>
              </tr>
            ))}
            {patients.length === 0 && (
              <tr><td colSpan={4} className="px-4 py-6 text-center text-slate-400">No patients found</td></tr>
            )}
          </tbody>
        </table>
      )}
    </div>
  );
}
