import { useEffect, useState } from 'react';
import { api } from '../api/client';

interface Appointment {
  id: string;
  startTime: string;
  endTime: string;
  status: string;
  reason?: string;
  patient: { firstName: string; lastName: string };
  provider: { firstName: string; lastName: string };
}

const statusColors: Record<string, string> = {
  SCHEDULED: 'bg-blue-100 text-blue-700',
  CONFIRMED: 'bg-teal-100 text-teal-700',
  CHECKED_IN: 'bg-amber-100 text-amber-700',
  COMPLETED: 'bg-slate-100 text-slate-600',
  CANCELLED: 'bg-red-100 text-red-700',
  NO_SHOW: 'bg-red-100 text-red-700',
};

export function Appointments() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/appointments').then((res) => {
      setAppointments(res.data);
      setLoading(false);
    });
  }, []);

  return (
    <div>
      <h2 className="text-xl font-bold text-slate-800 mb-6">Appointments</h2>
      {loading ? (
        <p className="text-slate-500 text-sm">Loading...</p>
      ) : (
        <div className="space-y-2">
          {appointments.map((a) => (
            <div key={a.id} className="bg-white border border-slate-200 rounded-lg p-4 flex items-center justify-between">
              <div>
                <p className="font-medium text-slate-800">
                  {a.patient.lastName}, {a.patient.firstName} — Dr. {a.provider.lastName}
                </p>
                <p className="text-sm text-slate-500">
                  {new Date(a.startTime).toLocaleString()} – {new Date(a.endTime).toLocaleTimeString()}
                </p>
                {a.reason && <p className="text-sm text-slate-400">{a.reason}</p>}
              </div>
              <span className={`text-xs font-medium px-2 py-1 rounded-full ${statusColors[a.status] ?? ''}`}>
                {a.status}
              </span>
            </div>
          ))}
          {appointments.length === 0 && <p className="text-slate-400 text-sm">No appointments scheduled</p>}
        </div>
      )}
    </div>
  );
}
